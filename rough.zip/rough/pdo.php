<?php
$user = 'root';
$pass = '';
try {
    $dbh = new PDO('mysql:host=localhost:3306;dbname=androiddb', $user, $pass);
    foreach($dbh->query('SELECT * from employee') as $row) {
        echo($row['name']);
    }
    $dbh = null;
} catch (PDOException $e) {
    print "Error!: " . $e->getMessage() . "<br/>";
    die();
}
?>