<?php
$user = 'root';
$pass = '';
try{
$conn = new PDO('mysql:host=localhost:3306;dbname=androiddb', $user, $pass);
$sql = 'update employee set name = :name, designation = :designation, salary = :salary where id = :id';
$stmt = $conn->prepare($sql);
$stmt->bindParam(':id', $_GET['id'], PDO::PARAM_STR);
$stmt->bindParam(':name', $_GET['name'], PDO::PARAM_STR);
$stmt->bindParam(':designation', $_GET['designation'], PDO::PARAM_STR);
$stmt->bindParam(':salary', $_GET['salary'], PDO::PARAM_STR);
$stmt -> execute();
}
catch (PDOException $pe){
die("Could not connect to the database :" . $pe->getMessage());
}
?>