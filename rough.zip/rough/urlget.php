<?php
	if(isset($_GET['id']) and isset($_GET['name']))
		echo 'got that '.$_GET['id'].' and name is '.$_GET['name'];
	else
		echo 'didnt get that';
?>